import logging
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import UserRegistrationForm, ProfileForm

logger = logging.getLogger('accounts')

def register(request):
    """
    Handles user registration.
    Security: Uses Django UserRegistrationForm which handles password hashing 
    and input validation automatically, preventing common injection and weak password issues.
    """
    if request.user.is_authenticated:
        return redirect('posts:feed')
        
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            logger.info(f"New user registered: {username}")
            return redirect('accounts:login')
    else:
        form = UserRegistrationForm()
    return render(request, 'accounts/register.html', {'form': form})

@login_required
def profile(request):
    """
    Handles viewing and updating the user's own profile.
    Security: 
    - @login_required ensures only authenticated users access this view.
    - Uses request.user.profile to ensure a user can ONLY access their OWN profile.
    - This prevents Insecure Direct Object Reference (IDOR) vulnerabilities 
      where a user might try to access another user's profile via a URL parameter.
    - Input validation is handled by ProfileForm.
    """
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=request.user.profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated!')
            logger.info(f"User {request.user.username} updated their profile.")
            return redirect('accounts:profile')
    else:
        form = ProfileForm(instance=request.user.profile)
    
    return render(request, 'accounts/profile.html', {'form': form})
