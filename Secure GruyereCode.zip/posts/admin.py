from django.contrib import admin
from .models import Post

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('author', 'created_at', 'attachment')
    list_filter = ('created_at', 'author')
    search_fields = ('content', 'author__username')
