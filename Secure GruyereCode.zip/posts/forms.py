from django import forms
from django.core.exceptions import ValidationError
from .models import Post, Upload

MAX_FILE_SIZE = 2 * 1024 * 1024  # 2MB

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['content', 'attachment']

    def clean_attachment(self):
        file = self.cleaned_data.get('attachment')
        if file:
            if file.size > MAX_FILE_SIZE:
                raise ValidationError("File size too large. Max size is 2MB.")
        return file

class UploadForm(forms.ModelForm):
    class Meta:
        model = Upload
        fields = ['file', 'description']

    def clean_file(self):
        file = self.cleaned_data.get('file')
        if file:
            if file.size > MAX_FILE_SIZE:
                raise ValidationError("File size too large. Max size is 2MB.")
        return file
