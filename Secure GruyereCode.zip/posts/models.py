import os
from django.db import models
from django.contrib.auth.models import User
from django.core.validators import FileExtensionValidator

def user_directory_path(instance, filename):
    # file will be uploaded to MEDIA_ROOT/uploads/user_<id>/<filename>
    return f'uploads/user_{instance.author.id}/{filename}'

class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField()
    attachment = models.FileField(
        upload_to=user_directory_path, 
        blank=True, 
        null=True,
        validators=[FileExtensionValidator(allowed_extensions=['jpg', 'jpeg', 'png', 'gif', 'txt', 'pdf'])]
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def is_image(self):
        if not self.attachment:
            return False
        ext = os.path.splitext(self.attachment.url)[1].lower()
        return ext in [".png", ".jpg", ".jpeg", ".gif"]

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Post by {self.author.username} at {self.created_at}"

class Upload(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='uploads')
    file = models.FileField(
        upload_to=user_directory_path,
        validators=[FileExtensionValidator(allowed_extensions=['jpg', 'jpeg', 'png', 'gif', 'txt', 'pdf'])]
    )
    description = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Upload by {self.author.username} - {self.file.name}"
