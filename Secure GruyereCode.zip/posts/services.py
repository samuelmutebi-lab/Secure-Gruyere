import logging
from django.core.exceptions import PermissionDenied

logger = logging.getLogger('posts')

def validate_ownership(user, obj):
    """
    Ensures the user owns the object.
    Security: Prevents IDOR by verifying that the requesting user 
    is indeed the author of the content they are trying to modify/delete.
    """
    if obj.author != user:
        logger.warning(f"Unauthorized access attempt by user {user.username} on object {obj.id}")
        raise PermissionDenied("You do not have permission to perform this action.")
