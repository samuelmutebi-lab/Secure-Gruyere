import logging
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Post, Upload
from .forms import PostForm, UploadForm
from .services import validate_ownership

logger = logging.getLogger('posts')

@login_required
def my_snippets(request):
    """
    Displays snippets created by the logged-in user.
    Security: Explicitly filters by request.user.
    """
    posts = Post.objects.filter(author=request.user)
    return render(request, 'posts/feed.html', {'posts': posts, 'title': 'My Snippets'})

@login_required
def upload_file(request):
    """
    Handles standalone file uploads.
    Security: 
    - Restricted file types and size.
    - Path isolation via user_directory_path.
    """
    if request.method == 'POST':
        form = UploadForm(request.POST, request.FILES)
        if form.is_valid():
            upload = form.save(commit=False)
            upload.author = request.user
            upload.save()
            messages.success(request, 'File uploaded successfully!')
            logger.info(f"User {request.user.username} uploaded file {upload.id}")
            return redirect('posts:feed')
    else:
        form = UploadForm()
    
    # Also show previous uploads for this user
    user_uploads = Upload.objects.filter(author=request.user)
    return render(request, 'posts/upload.html', {'form': form, 'uploads': user_uploads})
@login_required
def feed(request):
    """
    Displays a feed of all posts.
    Security: Relies on Django's ORM and auto-escaping in templates to prevent 
    SQLi and XSS.
    """
    posts = Post.objects.all()
    return render(request, 'posts/feed.html', {'posts': posts})

@login_required
def post_create(request):
    """
    Handles creating a new post.
    Security:
    - @login_required ensures only authenticated users can post.
    - Uses PostForm for strict input validation.
    - Manually assigns author from request.user to prevent impersonation.
    """
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            messages.success(request, 'Post created successfully!')
            logger.info(f"User {request.user.username} created post {post.id}")
            return redirect('posts:feed')
    else:
        form = PostForm()
    return render(request, 'posts/post_form.html', {'form': form, 'title': 'New Post'})
@login_required
def post_detail(request, pk):
    """
    Displays an individual post.
    Security: get_object_or_404 prevents leaking information about non-existent objects.
    """
    post = get_object_or_404(Post, pk=pk)
    return render(request, 'posts/post_detail.html', {'post': post})

@login_required
def post_update(request, pk):
    """
    Handles updating an existing post.
    Security:
    - validate_ownership(request.user, post) prevents IDOR.
    - PostForm ensures input sanitization.
    """
    post = get_object_or_404(Post, pk=pk)
    validate_ownership(request.user, post)
    
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            messages.success(request, 'Post updated successfully!')
            logger.info(f"User {request.user.username} updated post {post.id}")
            return redirect('posts:post_detail', pk=post.pk)
    else:
        form = PostForm(instance=post)
    return render(request, 'posts/post_form.html', {'form': form, 'title': 'Edit Post'})

@login_required
def post_delete(request, pk):
    """
    Handles deleting a post.
    Security:
    - Requires POST request to prevent CSRF-based deletions.
    - validate_ownership(request.user, post) prevents IDOR.
    """
    post = get_object_or_404(Post, pk=pk)
    validate_ownership(request.user, post)
    
    if request.method == 'POST':
        post.delete()
        messages.success(request, 'Post deleted successfully!')
        logger.info(f"User {request.user.username} deleted post {pk}")
        return redirect('posts:feed')
    
    return render(request, 'posts/post_confirm_delete.html', {'post': post})
